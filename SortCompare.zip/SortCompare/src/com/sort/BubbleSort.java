package com.sort;

public class BubbleSort extends AbstractSort
{
	public BubbleSort(int[] array)
	{
		super(array);
	}

	@Override
	protected void sort()
	{
		for (int i = array.length-1; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				if (array[j] > array[j + 1]) {
					Utils.swap(array, j, j + 1);
				}
			}
		}
	}
}
