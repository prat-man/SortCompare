package com.sort;

public class InsertionSort extends AbstractSort
{
	public InsertionSort(int[] array)
	{
		super(array);
	}

	@Override
	protected void sort()
	{
		for (int i = 1; i < array.length; i++) {
			for (int j = i; j > 0; j--) {
				if (array[j - 1] > array[j]) {
					Utils.swap(array, j - 1, j);
				}
			}
		}
	}
}
