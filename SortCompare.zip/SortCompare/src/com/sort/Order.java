package com.sort;

public enum Order {
	ASCENDING, DESCENDING
}
