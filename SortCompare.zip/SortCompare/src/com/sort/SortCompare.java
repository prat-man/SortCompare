package com.sort;

import java.util.ArrayList;

public class SortCompare
{
	private int[] array;
	
	private ArrayList<Runnable> sorts;
	
	public SortCompare(int size, Order order, double randomization)
	{
		this.sorts = new ArrayList<>();
		
		this.array = new int[size];
		
		for (int i = 0; i < array.length; i++) {
			if (order == Order.ASCENDING) {
				this.array[i] = i;
			}
			else {
				this.array[i] = array.length - i - 1;
			}
		}
		
		int rand = (int) (randomization * size);
		
		for (int i = 0; i < rand; i++) {
			int ind1 = (int) (Math.random() * ((size - 1) - 0 + 1));
			int ind2 = (int) (Math.random() * ((size - 1) - 0 + 1));
			Utils.swap(array, ind1, ind2);
		}
		
		sorts.add(new BubbleSort(array));
		sorts.add(new InsertionSort(array));
		sorts.add(new SelectionSort(array));
		sorts.add(new QuickSort(array));
	}
	
	public void start()
	{
		for (Runnable sort : sorts) {
			Thread thread = new Thread(sort);
			thread.start();
		}
	}
}
