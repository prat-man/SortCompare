package com.sort;

public class SortCompareMain
{
	public static void main(String[] args)
	{
		SortCompare sc = new SortCompare(10000, Order.ASCENDING, 0.5);
		
		sc.start();
	}
}
