package com.sortcompare;

import java.util.ArrayList;

import com.sortcompare.ex.ExecutionMode;
import com.sortcompare.ex.SortOrder;
import com.sortcompare.ex.Utils;
import com.sortcompare.sorts.AbstractSort;
import com.sortcompare.sorts.SortListener;

public class SortCompare implements SortListener
{
	private int[] array;
	
	private ArrayList<AbstractSort> sorts;
	
	private ExecutionMode mode;
	
	public SortCompare(int size, SortOrder order, double randomization)
	{
		this(size, order, randomization, ExecutionMode.PARALLEL);
	}
	
	public SortCompare(int size, SortOrder order, double randomization, ExecutionMode mode)
	{
		this.sorts = new ArrayList<>();
		
		this.array = new int[size];
		
		this.mode = mode;
		
		for (int i = 0; i < array.length; i++) {
			if (order == SortOrder.ASCENDING) {
				this.array[i] = i;
			}
			else {
				this.array[i] = array.length - i - 1;
			}
		}
		
		int rand = (int) (randomization * size);
		
		for (int i = 0; i < rand; i++) {
			int ind1 = (int) (Math.random() * ((size - 1) - 0 + 1));
			int ind2 = (int) (Math.random() * ((size - 1) - 0 + 1));
			Utils.swap(array, ind1, ind2);
		}
	}
	
	public void start()
	{
		for (AbstractSort sort : sorts) {
			// initialize the sort
			sort.init(array);
			
			// add listener
			sort.addListener(this);
			
			// create a new tread
			Thread thread = new Thread(sort);
			
			// start execution of the thread
			thread.start();
			
			// in sequential mode wait for thread to complete
			if (mode == ExecutionMode.SEQUENTIAL) {
				try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void addSort(AbstractSort sort)
	{
		sorts.add(sort);
	}

	@Override
	public void sortCompleted(AbstractSort sort) {
		sort.destroy();
	}
}
