package com.sortcompare;

import com.sortcompare.ex.ExecutionMode;
import com.sortcompare.ex.SortOrder;

public class SortCompareMain
{
	public static void main(String[] args)
	{
		SortCompare sc = new SortCompare(10000, SortOrder.ASCENDING, 0.5, ExecutionMode.PARALLEL);
		
		sc.start();
	}
}
