package com.sortcompare;

import com.sortcompare.ex.ExecutionMode;
import com.sortcompare.ex.SortOrder;
import com.sortcompare.sorts.BubbleSort;
import com.sortcompare.sorts.BucketSort;
import com.sortcompare.sorts.HeapSort;
import com.sortcompare.sorts.InsertionSort;
import com.sortcompare.sorts.MergeSort;
import com.sortcompare.sorts.PendulumSort;
import com.sortcompare.sorts.QuickSort;
import com.sortcompare.sorts.RadixSort;
import com.sortcompare.sorts.SelectionSort;

public class SortCompareMain
{
	public static void main(String[] args)
	{
		SortCompare sc = new SortCompare(10000, SortOrder.ASCENDING, 0.5, ExecutionMode.PARALLEL);
		
		sc.addSort(new BubbleSort());
		sc.addSort(new InsertionSort());
		sc.addSort(new SelectionSort());
		
		sc.addSort(new QuickSort());
		sc.addSort(new MergeSort());
		sc.addSort(new RadixSort());
		sc.addSort(new HeapSort());
		sc.addSort(new BucketSort());
		
		sc.addSort(new PendulumSort());
		
		sc.start();
	}
}
