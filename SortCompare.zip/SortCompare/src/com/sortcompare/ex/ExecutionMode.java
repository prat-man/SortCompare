package com.sortcompare.ex;

public enum ExecutionMode {
	PARALLEL, SEQUENTIAL
}
