package com.sortcompare.ex;

public enum SortOrder {
	ASCENDING, DESCENDING
}
