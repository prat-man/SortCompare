package com.sortcompare.ex;

public class Utils
{
	public static void swap(int[] arr, int ind1, int ind2)
	{
		int temp = arr[ind1];
		arr[ind1] = arr[ind2];
		arr[ind2] = temp;
	}
	
	public static int[] clone(int[] arr)
	{
		int[] copy = new int[arr.length];
		
		for (int i = 0; i < arr.length; i++) {
			copy[i] = arr[i];
		}
		
		return copy;
	}
	
	public static int getMin(int[] arr) 
    {
        int smallest = arr[0];
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < smallest) {
                smallest = arr[i];
            }
        }
        
        return smallest;
    }
	
	public static int getMax(int[] arr) 
    {
        int largest = arr[0];
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > largest) {
                largest = arr[i];
            }
        }
        
        return largest;
    }
}
