package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public abstract class AbstractSort implements Runnable
{
	protected int[] array;
	
	public AbstractSort() {}
	
	public void init(int[] array)
	{
		// defer cloning of array to reduce chances of heap overflow in sequential mode
		this.array = Utils.clone(array);
	}
	
	@Override
	public void run()
	{
		long start = System.currentTimeMillis();
		
		this.sort();
		
		long end = System.currentTimeMillis();
		
		long time = end - start;
		
		System.out.println(this.getClass().getSimpleName() + " Complete [" + time + " ms]");
	}
	
	protected abstract void sort();
	
	protected void display()
	{
		for (int i = 0; i < array.length; i++) {
			if (i == array.length-1) {
				System.out.println(array[i]);
			}
			else {
				System.out.print(array[i] + ", ");
			}
		}
	}
}
