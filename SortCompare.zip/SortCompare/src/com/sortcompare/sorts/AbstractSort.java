package com.sortcompare.sorts;

import java.util.ArrayList;

import com.sortcompare.ex.Utils;

public abstract class AbstractSort implements Runnable
{
	protected int[] array;
	
	protected ArrayList<SortListener> sortListeners;
	
	protected SortState sortState;
	
	public AbstractSort() {
		this.sortListeners = new ArrayList<>();
		
		this.sortState = SortState.NEW;
	}
	
	public void init(int[] array)
	{
		if (this.sortState == SortState.DESTROYED) {
			throw new InvalidSortStateException(this);
		}
		
		// defer cloning of array to reduce chances of heap overflow in sequential mode
		this.array = Utils.clone(array);
		
		this.sortState = SortState.READY;
	}
	
	public void addListener(SortListener listener)
	{
		if (this.sortState == SortState.DESTROYED) {
			throw new InvalidSortStateException(this);
		}
		
		this.sortListeners.add(listener);
	}
	
	@Override
	public void run()
	{
		if (this.sortState == SortState.DESTROYED) {
			throw new InvalidSortStateException(this);
		}
		
		this.sortState = SortState.RUNNING;
		
		long start = System.currentTimeMillis();
		
		this.sort();
		
		long end = System.currentTimeMillis();
		
		long time = end - start;
		
		System.out.println(this.getClass().getSimpleName() + " Complete [" + time + " ms]");
		
		this.sortState = SortState.DONE;
		
		for (SortListener listener : sortListeners) {
			listener.sortCompleted(this);
		}
	}
	
	public void destroy()
	{
		if (this.sortState == SortState.DESTROYED) {
			throw new InvalidSortStateException(this);
		}
		
		// remove references to the array
		this.array = null;
		
		// request for garbage collector to run
		System.gc();
		
		this.sortState = SortState.DESTROYED;
	}
	
	protected abstract void sort();
	
	protected void display()
	{
		if (this.sortState == SortState.DESTROYED) {
			throw new InvalidSortStateException(this);
		}
		
		for (int i = 0; i < array.length; i++) {
			if (i == array.length-1) {
				System.out.println(array[i]);
			}
			else {
				System.out.print(array[i] + ", ");
			}
		}
	}
}
