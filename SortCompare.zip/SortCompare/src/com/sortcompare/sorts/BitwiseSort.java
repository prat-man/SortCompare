package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public class BitwiseSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		// get largest element in array
		int max = array[0];
		
		for (int i = 1; i < array.length; i++) {
			if (array[i] > max) {
				max = array[i];
			}
		}
		
		// get maximum number of bits required to be sorted
		int maxBits = Integer.SIZE - Integer.numberOfLeadingZeros(max);
		
		// perform bitwise radix sort on the array
		radixSort(0, array.length - 1, maxBits);
	}
	
	protected void radixSort(int lb, int ub, int position) 
    {
		if (position < 0) return;
		
		// segregate by bits at position
		int pivot = segregate(lb, ub, position);
		
		// sort lower half
		radixSort(lb, pivot-1, position - 1);
		
		// sort upper half
		radixSort(pivot, ub, position - 1);
    }
	
	protected int segregate(int lb, int ub, int position)
	{
		// pivot index
		int index = lb;
		
		// loop through the range lb to ub
		for (int i = lb; i <= ub; i++) {
			// get bit at specified position
			int bit = (array[i] >> position) & 1;
			
			// bit is 0, swap with pivot and increase index of pivot by 1
			if (bit == 0) {
				Utils.swap(array, i, index++);
			}
		}
		
		// return pivot index
		return index;
	}
}
