package com.sortcompare.sorts;

import java.util.Arrays;

import com.sortcompare.ex.Utils;

public class BucketSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		bucketSort();
	}
	
	protected void bucketSort()
	{
		// get maximum value from array
		int minValue = Utils.getMin(array);
		int maxValue = Utils.getMax(array);
		
		int numBuckets = maxValue - minValue + 1;
		
		// declare a set of buckets
		int[] buckets = new int[numBuckets];
		
		// initialize the set of buckets
		Arrays.fill(buckets, 0);
		
		// sort array elements into buckets
		for (int i = 0; i < array.length; i++) {
			buckets[array[i] - minValue]++;
		}
		
		// concatenate the buckets into the array
		for (int i = 0, index = 0; i < numBuckets; i++) {
			for (int j = 0; j < buckets[i]; j++) {
				array[index++] = i + minValue;
			}
		}
	}
}
