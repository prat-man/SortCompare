package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public class HeapSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		heapSort();
	}
	
	protected void heapSort() 
    {
        // Build heap (rearrange array) 
        for (int i = array.length / 2 - 1; i >= 0; i--) {
            heapify(array.length, i); 
        }
  
        // One by one extract an element from heap 
        for (int i = array.length - 1; i>=0; i--) { 
            // Move current root to end
            Utils.swap(array, 0, i);
  
            // call max heapify on the reduced heap 
            heapify(i, 0);
        } 
    } 
  
    // To heapify a subtree rooted with node i which is 
    // an index in array[]. n is size of heap
    protected void heapify(int n, int i) 
    { 
        int largest = i;	// Initialize largest as root 
        int l = 2 * i + 1;	// left = 2*i + 1 
        int r = 2 * i + 2;	// right = 2*i + 2 
  
        // If left child is larger than root 
        if (l < n && array[l] > array[largest]) {
        	largest = l;
        }
  
        // If right child is larger than largest so far 
        if (r < n && array[r] > array[largest]) {
        	largest = r;
        }
  
        // If largest is not root 
        if (largest != i) {
        	// Swap i and largest elements
            Utils.swap(array, i, largest);
  
            // Recursively heapify the affected sub-tree 
            heapify(n, largest);
        } 
    }
}
