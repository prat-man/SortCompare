package com.sortcompare.sorts;

public class InsertionSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		for (int i = 1; i < array.length; i++) {
			int element = array[i];
			int index = i - 1;
			
			while (index >= 0 && array[index] > element) {
				array[index + 1] = array[index];
				index--;
			}
			
			if (index + 1 != i) {
				array[index + 1] = element;
			}
		}
	}
}
