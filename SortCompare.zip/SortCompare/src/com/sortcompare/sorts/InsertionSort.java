package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public class InsertionSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		for (int i = 1; i < array.length; i++) {
			for (int j = i; j > 0; j--) {
				if (array[j - 1] > array[j]) {
					Utils.swap(array, j - 1, j);
				}
			}
		}
	}
}
