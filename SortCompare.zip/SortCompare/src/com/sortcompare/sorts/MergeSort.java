package com.sortcompare.sorts;

public class MergeSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		mergeSort(0, array.length - 1);
	}
	
	protected void mergeSort(int lb, int ub)
	{
		if (lb >= ub) {
			return;
		}
		
		int mid = (lb + ub) / 2;
		
		mergeSort(lb, mid);
		mergeSort(mid + 1, ub);
		
		merge(lb, mid, ub);
	}
	
	protected void merge(int lb, int mid, int ub)
	{
		int[] temp = new int[ub - lb + 1];
		
		int index = 0;
		int i = lb;
		int j = mid + 1;
		
		while (i <= mid && j <= ub) {
			if (array[i] < array[j]) {
				temp[index++] = array[i++];
			}
			else {
				temp[index++] = array[j++];
			}
		}
		
		while (i <= mid) {
			temp[index++] = array[i++];
		}
		
		while (j <= ub) {
			temp[index++] = array[j++];
		}
		
		for (int p = lb, q = 0; p <= ub; p++, q++) {
			array[p] = temp[q];
		}
	}
}
