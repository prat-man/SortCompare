package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public class PendulumSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		int start = 0;
		int end = array.length - 1;
		int index = start;
		
		while (start < end)
		{
			int smallest = start;
			
			for (int i = start+1; i <= end; i++) {
				if (array[i] < array[smallest]) {
					smallest = i;
				}
			}
			
			Utils.swap(array, index, smallest);
			
			if (index == start) {
				index = end;
				start++;
			}
			else {
				index = start;
				end--;
			}
		}
	}
}
