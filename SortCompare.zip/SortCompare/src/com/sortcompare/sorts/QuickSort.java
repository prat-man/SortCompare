package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public class QuickSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		quickSort(0, array.length-1);
	}
	
	protected void quickSort(int lb, int ub)
	{
		if (lb < ub)
	    {
	        // pivot is partitioning index
			int pivot = partition(lb, ub);
			// array[pivot] is now at right place

	        quickSort(lb, pivot - 1); // before pivot
	        quickSort(pivot + 1, ub); // after pivot
	    }
	}
	
	protected int partition(int lb, int ub)
	{
	    // pivot (element to be placed at right position)
		int pivot = array[(lb + ub) / 2];
	    
	    int i = (lb - 1);  // index of smaller element

	    for (int j = lb; j <= ub - 1; j++) {
	        // if current element is smaller than or equal to pivot
	        if (array[j] <= pivot) {
	            i++;	// increment index of smaller element
	            Utils.swap(array, i, j);
	        }
	    }
	    
	    Utils.swap(array, i + 1, ub);

	    return (i + 1);
	}
}
