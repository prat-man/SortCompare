package com.sortcompare.sorts;

import java.util.Arrays;

import com.sortcompare.ex.Utils;

public class RadixSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		radixSort();
	}
	
	protected void radixSort() 
    { 
        // Find the maximum number to know number of digits
        int m = Utils.getMax(array); 
  
        // Do counting sort for every digit. Note that instead
        // of passing digit number, exp is passed. exp is 10^i
        // where i is current digit number
        for (int exp = 1; m/exp > 0; exp *= 10) 
            countSort(exp); 
    }
	
	protected void countSort(int exp) 
    {
		// Array to store the output of count sort
        int output[] = new int[array.length];
        
        // Array to store the count from 0 to 9
        int count[] = new int[10];
        Arrays.fill(count, 0); 
  
        // Store count of occurrences in count[]
        for (int i = 0; i < array.length; i++) {
            count[(array[i] / exp) % 10]++; 
        }
  
        // Change count[i] so that count[i] now contains
        // actual position of this digit in output[]
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
  
        // Build the output array
        for (int i = array.length - 1; i >= 0; i--) { 
            output[count[(array[i] / exp) % 10] - 1] = array[i]; 
            count[(array[i] / exp) % 10]--; 
        } 
  
        // Copy the output array to array[], so that array[] now
        // contains sorted numbers according to current digit
        for (int i = 0; i < array.length; i++) {
        	array[i] = output[i]; 
        }
    }
}
