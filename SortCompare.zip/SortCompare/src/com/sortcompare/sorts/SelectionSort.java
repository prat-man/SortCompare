package com.sortcompare.sorts;

import com.sortcompare.ex.Utils;

public class SelectionSort extends AbstractSort
{
	@Override
	protected void sort()
	{
		for (int i = 1; i < array.length; i++) {
			for (int j = i; j > 0; j--) {
				if (array[j - 1] > array[j]) {
					Utils.swap(array, j - 1, j);
				}
			}
		}
		for (int i = 0; i < array.length - 1; i++)
		{
		    int index = i;
		    
		    for (int j = i + 1; j < array.length; j++) {
		        if (array[j] < array[index]) {
		            index = i;
		        }
		    }

		    if (index != i) {
		    	Utils.swap(array, i, index);
		    }
		}
	}
}
