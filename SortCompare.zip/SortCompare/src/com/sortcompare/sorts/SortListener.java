package com.sortcompare.sorts;

public interface SortListener
{
	public void sortCompleted(AbstractSort sort);
}
