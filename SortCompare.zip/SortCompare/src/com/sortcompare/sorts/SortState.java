package com.sortcompare.sorts;

public enum SortState {
	NEW, READY, RUNNING, DONE, DESTROYED
}
