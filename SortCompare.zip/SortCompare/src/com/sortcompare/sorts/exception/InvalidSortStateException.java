package com.sortcompare.sorts.exception;

import com.sortcompare.sorts.AbstractSort;

public class InvalidSortStateException extends RuntimeException
{
	private static final long serialVersionUID = -3183205855031269204L;
	
	private AbstractSort sort;

	public InvalidSortStateException(AbstractSort sort)
	{
		this.sort = sort;
	}

	/**
	 * @return the sort
	 */
	public AbstractSort getSort() {
		return sort;
	}
}
